
#define FsADC		10000

void InitADC(int fs)
{
	ADC_CLOCK_SETUP_T adc;
	Chip_ADC_Init(LPC_ADC, &adc);
	Chip_ADC_SetSampleRate(LPC_ADC, &adc, fs);
	Chip_ADC_EnableChannel(LPC_ADC, ADC_CH0, ENABLE);
	Chip_ADC_Int_SetChannelCmd(LPC_ADC, ADC_CH0, ENABLE);
	Chip_ADC_SetBurstCmd(LPC_ADC, ENABLE);
	NVIC_EnableIRQ(ADC_IRQn);
	NVIC_SetPriority(ADC_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+1);
}

void ADC_IRQHandler(void)
{
	static uint16_t data;
	Chip_ADC_ReadValue(LPC_ADC, ADC_CH0, &data);
	Chip_DAC_UpdateValue(LPC_DAC,1023-((data>>2)&0x3FF));
}

static void initHardware(void)
{
    SystemCoreClockUpdate();
    Board_Init();
    Chip_DAC_Init(LPC_DAC);
    InitADC(FsADC);
    Board_LED_Set(0, false);
}

void task(void * a)
{
	while (1)
	{
		Board_LED_Toggle(0);
		vTaskDelay(250 / portTICK_RATE_MS);
	}
}

/*int main(void)
{
	initHardware();
	xTaskCreate(task, (const char *)"task", configMINIMAL_STACK_SIZE*2, 0, tskIDLE_PRIORITY+1, 0);
	vTaskStartScheduler();
	for(;;);
}*/
