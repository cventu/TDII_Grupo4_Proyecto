

static void initHardware(void)
{
    SystemCoreClockUpdate();
    Board_Init();
    Board_LED_Set(0, false);
    InicializarUart(__UART_2,115200);
}

static void TareaLed(void * a)
{
	while (1) {
		Board_LED_Toggle(0);
		vTaskDelay(250 / portTICK_RATE_MS);
	}
}

char mayusculas(char dato)
{
	if(dato>='a' && dato<='z')
	{
		dato = dato - 'a' + 'A';
	}
	return dato;
}

static void TareaSerie(void *p)
{
	char dato;
	while(1)
	{
		dato= getcharUart(__UART_2);
		putcharUart(__UART_2,mayusculas(dato));
	}
}

/*int main(void)
{
	initHardware();
	xTaskCreate(TareaLed, 	(const char *)"LED", configMINIMAL_STACK_SIZE*2, 0, tskIDLE_PRIORITY+1, 0);
	xTaskCreate(TareaSerie, (const char *)"ECO", configMINIMAL_STACK_SIZE*2, 0, tskIDLE_PRIORITY+1, 0);
	vTaskStartScheduler();
	while (1);
}*/
